package tst.trabalho.Pratica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PraticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
