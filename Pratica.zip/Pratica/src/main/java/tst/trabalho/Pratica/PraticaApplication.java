package tst.trabalho.Pratica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PraticaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PraticaApplication.class, args);
	}

}
